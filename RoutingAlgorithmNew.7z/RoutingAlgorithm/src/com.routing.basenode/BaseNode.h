/*
 * BaseNode.h
 *
 *  Created on: Jul 7, 2017
 *      Author: admin
 */

#ifndef BASENODE_H_
#define BASENODE_H_

#include <string.h>
#include <omnetpp.h>
#include "Message_m.h"
#define SIMTIME 1

using namespace omnetpp;
class BaseNode : public cSimpleModule
{
  public:
    BaseNode();

      int x_new , y_new, id_new;
       double dataPeriod;
       bool isSource;
       cMessage *helloTimer;
       cMessage *dataTimer;
       void sendHello();
       void sendData(Data*);
       double range;
       int countPkt;

       std::vector<Node> nbList;
       std::vector<Node> networkList;
       static  bool check;
       Node *mySelf, *dest;
       int numHosts;
       virtual void initialize() override;
       virtual void handleMessage(cMessage *msg) override;
       Node* getNextHopByGreedy(Point &dest);
       virtual void finish() override;
       void init();
       void dumpNeighbors();
       Node* getNeighbor(int id);
       void addNeighbor(Node &node);
       void getNode();
};

/*
 * Xay dung baseNode la node co ban ke thua cSimpleModule
 * Cac node con lai ke thua tren baseNode
 * Duyet theo BaseNode
 * Neu cai nao la GreedyNode thi se tinh toan thuat toan dinh tuyet
 * Neu cai nao la MainRoom thi se thuc hien viec nhet thong tin cac node vao
 * :D :D :D
 *
 *
 * */
#endif /* BASENODE_H_ */
