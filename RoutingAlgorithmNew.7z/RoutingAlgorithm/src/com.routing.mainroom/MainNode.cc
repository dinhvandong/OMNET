/*
 * MainNode.cc
 *
 *  Created on: Jul 7, 2017
 *      Author: admin
 */




#include <string.h>
#include <omnetpp.h>
#include<MainNode.h>
#include<Node.h>
#include<Message_m.h>
#include<BaseNode.h>
using namespace omnetpp;
// The module class needs to be registered with OMNeT++
Define_Module(MainNode);
MainNode::MainNode(){
}
void MainNode::initialize()
{
    numHosts = (int )(this->getParentModule()->par("numHosts"));
    helloTimer = new cMessage("HelloTimer");
    scheduleAt(simTime()+1,helloTimer);
}
void MainNode::handleMessage(cMessage *msg)
{
    CreateNetworkList();
}
void MainNode::CreateNetworkList(){
    for (int i = 0;i<numHosts;i++){
      BaseNode *nH =(BaseNode*)(this->getParentModule()->getSubmodule("host",i));
      /* goi ham nH->getNode de lay thong tin location cua BaseNode */
      nH->getNode();
      Node *tempNode = new Node(nH->id_new, nH->x_new,nH->y_new);
      networkList.push_back(*tempNode);
     }
}

