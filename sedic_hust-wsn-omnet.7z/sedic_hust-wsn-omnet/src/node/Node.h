#pragma once

#include <L3Address.h>
#include <GeoMathHelper.h>

using namespace inet;

namespace wsn {
class Node: public Point {
private:
	int _id;
	L3Address _addr;
public:
	Node();
	Node(double x, double y);
	Node(int id, L3Address addr, double x, double y);
	int id() const {
		return _id;
	}
	L3Address address() const {
		return _addr;
	}
};

} /* namespace wsn */

