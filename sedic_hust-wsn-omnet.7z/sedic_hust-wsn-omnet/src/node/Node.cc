#include <Node.h>

namespace wsn {
Node::Node() {
}

Node::Node(double x, double y) :
		Point(x, y) {
}

Node::Node(int id, L3Address addr, double x, double y) :
		Point(x, y) {
	_id = id;
	_addr = addr;
}

} /* namespace wsn */
