#pragma once

#include <omnetpp/csimplemodule.h>
#include <omnetpp.h>
#include <vector>

using namespace omnetpp;

namespace wsn {

void logBoundHoleDrop(int pid, const char*reason);
void logBoundHoleRecv(int pid, int myid);
void logDrop(const char* reason);
void logSend(cMessage *msg);
void logRecv(cMessage *msg);

void logBoundHoleDrop(int pid, const char*reason) {
	FILE *fp = fopen("Trace.tr", "a");
	fprintf(fp, "D %s %d %s ", SIMTIME_STR(getSimulation()->getSimTime()), pid, reason);
//	for(auto n : data) {
//		fprintf(fp, "%d,", n.id());
//	}
	fprintf(fp, "\n");
	fclose(fp);
}

void logBoundHoleRecv(int pid, int myid) {
	FILE *fp = fopen("Trace.tr", "a");
	fprintf(fp, "R %s %d:%d\n", SIMTIME_STR(getSimulation()->getSimTime()), pid, myid);
	fclose(fp);
}

void logDrop(const char* reason) {
	FILE *fp = fopen("Trace.tr", "a");
	fprintf(fp, "D %s %s\n", SIMTIME_STR(getSimulation()->getSimTime()), reason);
	fclose(fp);
}

void logSend(cMessage *msg) {
	FILE *fp = fopen("Trace.tr", "a");
	fprintf(fp, "S %ld %s\n", msg->getId(), SIMTIME_STR(getSimulation()->getSimTime()));
	fclose(fp);
}

void logRecv(cMessage *msg) {
	FILE *fp = fopen("Trace.tr", "a");
	fprintf(fp, "R %ld %s\n", msg->getId(), SIMTIME_STR(getSimulation()->getSimTime()));
	fclose(fp);
}

}
