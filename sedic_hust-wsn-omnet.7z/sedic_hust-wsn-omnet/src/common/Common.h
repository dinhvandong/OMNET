#pragma once

#include <IPv4ControlInfo.h>
#include <Node.h>
#include <TLVOption_m.h>
#include <vector>

#define UDP_PORT    269
#define WSN_ROUTING	613

using namespace inet;

namespace wsn {

typedef TLVOptionBase RoutingInfo;
typedef IPv4ControlInfo IPInfo;

struct StuckAngle {
	Node a_;
	Node b_;

	StuckAngle(Node &a, Node &b) {
		a_ = a;
		b_ = b;
	}
};

class PolygonHole {
private:
	int _id;
	std::vector<Node> _nodeList;

public:
	PolygonHole(int id);
	PolygonHole();
	void addNode(Node& node);
	int id() const;
	std::vector<Node> nodeList();
};
}
