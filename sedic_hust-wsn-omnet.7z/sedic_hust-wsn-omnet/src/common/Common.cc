#include <Common.h>

using namespace inet;

namespace wsn {
PolygonHole::PolygonHole() :
		_id(-1) {
}

PolygonHole::PolygonHole(int id) :
		_id(id) {
}

void PolygonHole::addNode(Node &n) {
	_nodeList.push_back(n);
}

int PolygonHole::id() const {
	return _id;
}

std::vector<Node> PolygonHole::nodeList() {
	return _nodeList;
}
}
