//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#include "BoundHoleRouting.h"

namespace wsn {

Define_Module(BoundHoleRouting);

BoundHoleRouting::BoundHoleRouting() {}
BoundHoleRouting::~BoundHoleRouting() {}

RoutingInfo* BoundHoleRouting::createRoutingInfo() {
    BoundHoleHDR *hdr = new BoundHoleHDR();
    hdr->setMode(BH_GREEDY);
    hdr->setDest(*dest);
    hdr->setLength(computeOptionLength());
    return hdr;
}

int BoundHoleRouting::computeOptionLength() {
    //1 Point:sizeof(Point), 1 Mode(int): sizeof(int)
    //distanceToDest: sizeof(double), type & length of packet: 2bytes
    return sizeof(Point) + sizeof(int) + sizeof(double) + 2;
}

Node BoundHoleRouting::routing(RoutingInfo *routingInfo) {
    BoundHoleHDR *hdr = check_and_cast_nullable<BoundHoleHDR*>(routingInfo);
    Node nb;
    switch (hdr->getMode()) {
    case BH_GREEDY:
        nb = findGreedyRoutingNextHop(*dest);
        if(nb.address().isUnspecified()) {
            nb = getNextHopByBoundHole(*mySelf);
            if (nb.address().isUnspecified()) {
                delete(routingInfo); // DROP_RTR_NO_ROUTE
            } else {
                hdr->setMode(BH_BOUNDHOLE);
            }
        } else {
            hdr->setDistanceToDest(G::distance(mySelf, dest));
        }
        break;
    case BH_BOUNDHOLE:
        if(hdr->getDistanceToDest() > G::distance(mySelf, dest)) {
            nb = findGreedyRoutingNextHop(*dest);
            if(!nb.address().isUnspecified()) {
                hdr->setMode(BH_GREEDY);
                hdr->setDistanceToDest(G::distance(mySelf, dest));
            } else {
                nb = getNextHopByBoundHole(*mySelf);
                if(nb.address().isUnspecified()) {
                    delete(routingInfo); // DROP_RTR_NO_ROUTE
                }
            }
        } else {
            nb = getNextHopByBoundHole(*mySelf);
            if(nb.address().isUnspecified()) {
                delete(routingInfo); // DROP_RTR_NO_ROUTE
            }
        }
        break;
    default:
        throw cRuntimeError("Unknown routing mode");
        delete(routingInfo);
    }
    return nb;
}

Node BoundHoleRouting::getNextHopByBoundHole(Node p) {
    Node nb;
    std::vector<Node> list = holeList[0].nodeList();
    for(unsigned int i = 0; i < list.size(); i++) {
        if(*mySelf == list[i])
            nb = list[i+1];
    }
    return nb;
}
} //namespace
