//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#include "NHR.h"
#include <stack>
#include <NHRGraph.h>

namespace wsn {

Define_Module(NHR);

NHR::NHR() {
}
NHR::~NHR() {
}

void NHR::init() {
    delta_ = 2;
    delta_ = par("delta_");
    isSource = par("isSource");
    isPivot_ = true;  //default: endpoint of node is itself
    BoundHole::init();
}

void NHR::getLocation() {
    RoutingBaseAlgorithm::getLocation();
    endpoint_.x_ = mySelf->x_;
    endpoint_.y_ = mySelf->y_;
}
void NHR::startUp() {
    FILE *fp;
    fp = fopen("BroadcastRegion.tr", "w");
    fclose(fp);
    fp = fopen("Dump.tr", "w");
    fclose(fp);
    fp = fopen("Voronoi.tr", "w");
    fclose(fp);
    fp = fopen("ScalePolygon.tr", "w");
    fclose(fp);
    BoundHole::startUp();
}

void NHR::setupTimer() {
    if (isSource) {
        nhr_data_timer_ = new cMessage("NHRDataTimer");
        scheduleAt(simTime() + 300, nhr_data_timer_);
    }
    BoundHole::setupTimer();
} //actually, it's not need to setup timer, we can do this way: if receive a udp packet from upper layer, delete that udp packet
  //then create new NHRDataPacket and send it

void NHR::recvSelfMessage(cMessage* msg) {
    if (msg == nhr_data_timer_)
        sendData();
    else
        BoundHole::recvSelfMessage(msg);
}

void NHR::recvMessage(cPacket* packet, IPInfo* ipInfo) {
    if (dynamic_cast<NHRDataPacket*>(packet)) {
        auto nhr_pkt = static_cast<NHRDataPacket*>(packet);
        if (ipInfo->getHopLimit() <= 0) {
            //TODO: record DROP_RTR_TTL
            delete(packet);
            return;
        } else {
            ipInfo->setHopLimit(ipInfo->getHopLimit() - 1);
            recvData(nhr_pkt);
        }
    } else {
        if (strcmp(packet->getName(), "BroadcastHCI") == 0) {
            auto bh_pkt = static_cast<BoundHolePacket*>(packet);
            recvHCI(bh_pkt, ipInfo);
        }
        BoundHole::recvMessage(packet, ipInfo);
    }
}

/*----------------- Sending Data -------------------*/
void NHR::sendData() {
    NHRDataPacket *p = new NHRDataPacket("NHRDataPacket");
    p->setAp_index(0);
    p->setType(NHR_GPSR);
    p->setAnchor_points(0, *dest);
    p->setDest(*dest);
    recvData(p);
}

void NHR::recvData(NHRDataPacket *p) {
    if (p->getDest().x_ == mySelf->x_ && p->getDest().y_ == mySelf->y_) {
        delete(p); // packet's came to destination
        return;
    }

    Node nexthop;

    if (p->getType() == NHR_GPSR && !hole_.empty()) {
        p->setType(NHR_AWARE_SOURCE_ESCAPE);
        p->setAp_index(1);
        p->setAnchor_points(p->getAp_index(), endpoint_);
    }

    nexthop = findGreedyRoutingNextHop(p->getAnchor_points(p->getAp_index()));
    if (nexthop.address().isUnspecified()) {
        switch (p->getType()) {
        case NHR_AWARE_SOURCE_ESCAPE:
            p->setAnchor_points(1, endpoint_);
            if (isPivot_) {
                p->setType(NHR_AWARE_SOURCE_PIVOT);
            }
            nexthop = findGreedyRoutingNextHop(p->getAnchor_points(p->getAp_index()));
            if (!nexthop.address().isUnspecified()) break;
        case NHR_AWARE_SOURCE_PIVOT:
            if (determineOctagonAnchorPoints(p)) {
                p->setType(NHR_AWARE_OCTAGON);
            } else {
                p->setAp_index(0);
                p->setType(NHR_AWARE_DESTINATION);
            }
            nexthop = findGreedyRoutingNextHop(p->getAnchor_points(p->getAp_index()));
            if (!nexthop.address().isUnspecified()) break;
        case NHR_AWARE_OCTAGON:
            while (p->getAp_index() > 1 && nexthop.address().isUnspecified()) {
               p->setAp_index(p->getAp_index() - 1);
               nexthop = findGreedyRoutingNextHop(p->getAnchor_points(p->getAp_index()));
            }
            if (p->getAp_index() == 1) {
                p->setAp_index(0);
                p->setType(NHR_AWARE_DESTINATION);
            }
            nexthop = findGreedyRoutingNextHop(p->getAnchor_points(p->getAp_index()));
            if (!nexthop.address().isUnspecified()) break;
        case NHR_AWARE_DESTINATION:
            routeToDest(p);
            nexthop = findGreedyRoutingNextHop(p->getAnchor_points(p->getAp_index()));
            break;
        default:
            // TODO: record "DROP_RTR_NO_ROUTE"
            // delete(p);
            return;
        }
    }

    if (nexthop.address().isUnspecified()) {
        // TODO: record "DROP_RTR_NO_ROUTE"
        // delete(p);
        return;
    } else {
        sendUDPPacket(p, nexthop.address(), 128, 0);
    }
}

/*------------ Hole approximation -------------*/
void NHR::createPolygonHole(PolygonHole &hole) {
    unsigned int i = 0;
    std::vector<BoundaryNode> convex;

    NodeVector data = hole.nodeList();
    for (i = 0; i < data.size(); i++) {
        BoundaryNode bn;
        bn.id_ = data[i].id();
        bn.is_convex_hull_boundary_ = false;
        bn.x_ = data[i].x_;
        bn.y_ = data[i].y_;
        hole_.push_back(bn);
    }

    // 1. Determine convex hull of hole using Graham scan algorithm
    convex = determineConvexHull();

    // 2. Approximate hole
    approximateHole(convex);

    // 3 Determine caves - rotate hole list, i.e. the first element is convex hull boundary
    i = 0;
    while (!hole_[i].is_convex_hull_boundary_) i++;
    rotate(hole_.begin(), hole_.begin() + i, hole_.end());
    hole_.push_back(hole_[0]); //circulate the hole list

    dump();
}

/*------------ Broadcast phase -------------*/
void NHR::broadcastHCI() {
    BoundHolePacket *p = new BoundHolePacket("BroadcastHCI");

    if (hole_.empty())
        return;

    for (std::vector<BoundaryNode>::iterator it = octagon_hole_.begin(); it != octagon_hole_.end(); ++it) {
        Node *tmp = new Node(-1, L3Address(), (*it).x_, (*it).y_);
        p->getBoundholeNodes().push_back(*tmp);
    }
    for (std::vector<BoundaryNode>::iterator it = hole_.begin(); it != hole_.end(); ++it) {
        Node *tmp = new Node((*it).id_, L3Address(), (*it).x_, (*it).y_);
        p->getBoundholeNodes().push_back(*tmp);
    }
    p->setSourceId(mySelf->id());

    // don't need to construct graph because don't broadcast it

    sendUDPPacket(p, broadcastAddress(), 1, 0);
}

void NHR::recvHCI(BoundHolePacket *p, IPInfo *ctrlInfo) {
    //if the hci packet has came back to the initial node
    if (p->getSourceId() == mySelf->id()) {
        //TODO: record "Loop HCI"
        //delete(p);
        return;
    }
    if (ctrlInfo->getHopLimit() <= 0) { //TODO: check if inet auto -1 for ttl
        //delete(p);
        return;
    }

    // check if is really receive this hole's information
    if (!hole_.empty())  // already receive
    {
        //TODO: record "HCI received"
        //delete(p);
        return;
    }

    //store hci
    NodeVector data = p->getBoundholeNodes();
    for (unsigned int i = 0; i < 8; i++) {
        BoundaryNode n;
        n.id_ = data[i].id();
        n.x_ = data[i].x_;
        n.y_ = data[i].y_;
        octagon_hole_.push_back(n);
    }
    for (unsigned int i = 8; i < data.size(); i++) {
        BoundaryNode n;
        n.id_ = data[i].id();
        n.x_ = data[i].x_;
        n.y_ = data[i].y_;
        hole_.push_back(n);
    }

    if (!canBroadcast()) {
        //TODO: record "Out side region"
        delete(p);
    }

    //construct graph
    Point agent;
    agent.x_ = mySelf->x_;
    agent.y_ = mySelf->y_;
    NHRGraph *graph = new NHRGraph(agent, hole_);
    endpoint_ = graph->endpoint();
    isPivot_ = graph->isPivot();
    while (!isPivot_ && findGreedyRoutingNextHop(endpoint_).address().isUnspecified()) {
        graph->endpoint(endpoint_);
    }
    delete graph;

    dumpBroadcastRegion();
}

std::vector<BoundaryNode> NHR::determineConvexHull() {
    std::stack<BoundaryNode*> hull;
    std::vector<BoundaryNode> convex;
    std::vector<BoundaryNode*> clone_hole;

    for (std::vector<BoundaryNode>::iterator it = hole_.begin(); it != hole_.end(); ++it) {
        clone_hole.push_back(&(*it));
    }

    std::sort(clone_hole.begin(), clone_hole.end(), COORDINATE_ORDER());
    BoundaryNode *pivot = clone_hole.front();
    std::sort(clone_hole.begin() + 1, clone_hole.end(), POLAR_ORDER(*pivot));
    hull.push(clone_hole[0]);
    hull.push(clone_hole[1]);
    hull.push(clone_hole[2]);

    for (unsigned int i = 3; i < clone_hole.size(); i++) {
        BoundaryNode *top = hull.top();
        hull.pop();
        while (G::orientation(*hull.top(), *top, *clone_hole[i]) != 2) {
            top = hull.top();
            hull.pop();
        }
        hull.push(top);
        hull.push(clone_hole[i]);
    }

    while (!hull.empty()) {
        BoundaryNode *top = hull.top();
        top->is_convex_hull_boundary_ = true;
        convex.push_back(*top);
        hull.pop();
    }
    return convex;
}

//create octagon
void NHR::approximateHole(std::vector<BoundaryNode> convex) {
    /*
     * define 8 lines for new approximate hole
     *
     *          ____[2]_________
     *      [02]                [21]______
     *     /                              \
     *  [0] ----------------------------- [1]
     *     \____                       ___/
     *          [30]____   ________[13]
     *                  [3]
     */

    int n0, n1, n2, n3; // index of node h(p), h(q), h(k), h(j)
    Line bl;            // base line
    Line l0;            // line contain n0 and perpendicular with base line
    Line l1;            // line contain n1 and perpendicular with base line
    Line l2;            // line contain n2 and parallel with base line
    Line l3;            // line contain n3 and parallel with base line
    double longest_distance = 0;

    n0 = n1 = n2 = n3 = 0;

    // find 2 nodes that have maximum distance - n0, n1
    for (unsigned int i = 0; i < convex.size(); i++) {
        for (unsigned int j = i; j < convex.size(); j++) {
            double tmp_distance = G::distance(convex[i], convex[j]);
            if (longest_distance < tmp_distance) {
                longest_distance = tmp_distance;
                n0 = i;
                n1 = j;
            }
        }
    }

    bl = G::line(convex[n0], convex[n1]); // bl = h(p)h(q)
    l0 = G::perpendicular_line(convex[n0], bl);
    l1 = G::perpendicular_line(convex[n1], bl);

    // find n2 and n3 - with maximum distance from base line
    longest_distance = 0;
    for (unsigned int i = 0; i < convex.size(); i++) {
        double tmp_distance = G::distance(convex[i], bl);
        if (tmp_distance > longest_distance) {
            longest_distance = tmp_distance;
            n2 = i;
        }
    }
    longest_distance = 0;
    for (unsigned int i = 0; i < convex.size(); i++) {
        double tmp_distance = G::distance(convex[i], bl);
        if (tmp_distance > longest_distance && G::position(convex[n2], bl) * G::position(convex[i], bl) < 0) {
            longest_distance = tmp_distance;
            n3 = i;
        }
    }

    l2 = G::parallel_line(convex[n2], bl);
    l3 = G::parallel_line(convex[n3], bl);

    // approximate hole
    BoundaryNode itsp;  // intersect point (temporary)
    Line itsl;          // intersect line (temporary)
    double mc;

    //l02 intersection of l0 and l2
    G::intersection(l0, l2, itsp);
    itsl = G::angle_bisector(convex[n0], convex[n1], itsp);
    longest_distance = 0;
    mc = 0;
    for (unsigned int i = 0; i < convex.size(); i++) {
        itsl.c_ = -(itsl.a_ * convex[i].x_ + itsl.b_ * convex[i].y_);
        double tmp_distance = G::distance(convex[n3], itsl);
        if (tmp_distance > longest_distance) {
            longest_distance = tmp_distance;
            mc = itsl.c_;
        }
        itsl.c_ = mc;
        G::intersection(l0, itsl, itsp);
        octagon_hole_.push_back(itsp);
        G::intersection(l2, itsl, itsp);
        octagon_hole_.push_back(itsp);
    }

    //l21 intersection of l2 and l1
    G::intersection(l1, l2, itsp);
    itsl = G::angle_bisector(convex[n1], convex[n0], itsp);
    longest_distance = 0;
    mc = 0;
    for (unsigned int i = 0; i < convex.size(); i++) {
        itsl.c_ = -(itsl.a_ * convex[i].x_ + itsl.b_ * convex[i].y_);
        double tmp_distance = G::distance(convex[n3], itsl);
        if (tmp_distance > longest_distance) {
            longest_distance = tmp_distance;
            mc = itsl.c_;
        }
    }
    itsl.c_ = mc;
    G::intersection(l2, itsl, itsp);
    octagon_hole_.push_back(itsp);
    G::intersection(l1, itsl, itsp);
    octagon_hole_.push_back(itsp);

    // l13 intersection of l1 and l3
    G::intersection(l1, l3, itsp);
    itsl = G::angle_bisector(convex[n1], convex[n0], itsp);
    longest_distance = 0;
    mc = 0;
    for (unsigned int i = 0; i < convex.size(); i++) {
        itsl.c_ = -(itsl.a_ * convex[i].x_ + itsl.b_ * convex[i].y_);
        double dis = G::distance(convex[n2], itsl);
        if (dis > longest_distance) {
            longest_distance = dis;
            mc = itsl.c_;
        }
    }
    itsl.c_ = mc;
    G::intersection(l1, itsl, itsp);
    octagon_hole_.push_back(itsp);
    G::intersection(l3, itsl, itsp);
    octagon_hole_.push_back(itsp);

    // l30 intersection of l3 and l0
    G::intersection(l0, l3, itsp);
    itsl = G::angle_bisector(convex[n0], convex[n1], itsp);
    longest_distance = 0;
    mc = 0;
    for (unsigned int i = 0; i < convex.size(); i++) {
        itsl.c_ = -(itsl.a_ * convex[i].x_ + itsl.b_ * convex[i].y_);
        double dis = G::distance(convex[n2], itsl);
        if (dis > longest_distance) {
            longest_distance = dis;
            mc = itsl.c_;
        }
    }
    itsl.c_ = mc;
    G::intersection(l3, itsl, itsp);
    octagon_hole_.push_back(itsp);
    G::intersection(l0, itsl, itsp);
    octagon_hole_.push_back(itsp);
}

// check if node is inside NHR region, also calculate the scale factor = min distance from node to octagon
bool NHR::canBroadcast() {
    //std::vector<BoundaryNode*> convex;   //used for what?

    PolygonHole* node_list = new PolygonHole();

    for (unsigned int i = 0; i < octagon_hole_.size(); i++) {
        //convex.push_back(&octagon_hole_[i]);
        Node *n = new Node(octagon_hole_[i].x_, octagon_hole_[i].y_);
        node_list->addNode(*n);
    }

    double distance = distanceToPolygon(*node_list);
    if (distance <= delta_) {
        calculateScaleFactor(distance);
        return true;
    }

    return false;
}

void NHR::calculateScaleFactor(double d) {
    delta_ = d;
}

// actually that is distance to octagon
double NHR::distanceToPolygon(PolygonHole p) {
    std::vector<Node> polygon = p.nodeList();
    Node tmp0;
    Node tmp1;
    Node tmp2;
    Node tmp3;
    Line l, l1, l2; // l: line P(i+1)(i+2), l1: parallel with line P(i)P(i+1), l2: parallel with line P(i+2)P(i+3)

    // check if point inside polygon return maximum scale factor
    std::vector<Point> p_;
    for(unsigned int i = 0; i < polygon.size(); i++)
        p_.push_back(Point(polygon[i].x_, polygon[i].y_));
    if (G::isPointInsidePolygon(*mySelf, p_)) return delta_;

    double distance;
    double d = DBL_MAX;
    int n = 8; //number of octagon's vertices = 8

    for(unsigned int i = 0; n; i++, n--) {
        tmp0 = polygon[i];
        tmp1 = polygon[(i+1)%(polygon.size())];
        tmp2 = polygon[(i+2)%(polygon.size())];
        l = G::line(tmp1, tmp2);

        if(G::position(mySelf, &tmp0, &l) > 0) continue;

        distance = G::distance(mySelf, l);
        if (distance < d) {
            // detect if node stays on covering polygon's boundary
            tmp3 = polygon[(i+3)%(polygon.size())];
            l1 = G::line(tmp0, tmp1);
            l2 = G::line(tmp2, tmp3);

            int pos1 = G::position(mySelf, &tmp2, &l1);
            int pos2 = G::position(mySelf, &tmp1, &l2);

            if (pos1 * pos2 >= 0 && pos1 >= 0) {
                d = distance;
            } else if (pos1 * pos2 >= 0 && pos1 < 0) {
                if (G::distance(mySelf, l1) <= distance && G::distance(mySelf, l2) <= distance) {
                    d = distance;
                }
            } else {
                if ((pos1 < 0 && G::distance(mySelf, l1) <= distance) || (pos2 < 0 && G::distance(mySelf, l2) <= distance)) {
                    d = distance;
                }
            }
        }
    }

    return d/range;
}

Point NHR::calculateDestEndpoint(Point dest) {
    // TODO: if dest and source are in the same cave
    // return to routeToDest mode immediately
    Point gate_point;
    NHRGraph* graph = new NHRGraph(dest, hole_);
    gate_point = graph->isPivot() ? graph->endpoint() : graph->gatePoint();
    delete graph;
    return gate_point;
}

//source - dest-endpoint intersects with hole or not
bool NHR::sdPolygonIntersect(NHRDataPacket* pkt) {
    Point dest = pkt->getAnchor_points(0);
    int num_intersection = 0;

    for (unsigned int i = 0; i < hole_.size(); i++) {
        unsigned int j = (i == hole_.size() - 1 ? 0 : (i + 1));
        if (G::is_in_line(mySelf, &dest, hole_[i]) && G::is_in_line(mySelf, &dest, hole_[j])) break;
        if (G::is_intersect(mySelf, &dest, hole_[i], hole_[j])) num_intersection++;
    }

    return num_intersection > 0;
}

bool NHR::isPointInsidePolygon(Point p, std::vector<BoundaryNode> polygon) {
    std::vector<Point> polygon_;
    for(unsigned int i = 0; i < polygon.size(); i++) {
        polygon_.push_back(Point(polygon[i].x_, polygon[i].y_));
    }
    return G::isPointInsidePolygon(p, polygon_);
}

void NHR::findLimitAnchorPoint(Point point, std::vector<BoundaryNode> scaleHole, Point center, int &i1, int &i2) {
    i1 = i2 = -1;
    if (!isPointInsidePolygon(point, scaleHole)) {//point is outside scale hole
        findViewLimitVertices(point, scaleHole, i1, i2);
        return;
    } else {
        for (unsigned int i = 0; i < scaleHole.size(); i++) {
            if (G::isPointLiesInTriangle(&point, &center, &scaleHole[i % 8], &scaleHole[(i+1) % 8])) {
                i1 = i;
                i2 = (i + 1) % 8;
                return;
            }
        }
    }
}

void NHR::findViewLimitVertices(Point point, std::vector<BoundaryNode> polygon, int &i1, int &i2) {
    std::vector<BoundaryNode*> clone;
    for (unsigned int i = 0; i < polygon.size(); i++) {
        polygon[i].id_ = i;
        clone.push_back(&polygon[i]);
    }

    BoundaryNode pivot;
    pivot.x_ = point.x_;
    pivot.y_ = point.y_;
    std::sort(clone.begin(), clone.end(), POLAR_ORDER(pivot));
    i1 = clone[0]->id_;
    i2 = clone[clone.size() -1]->id_;
}

void NHR::routeToDest(NHRDataPacket* p) {
    NHRGraph* graph = new NHRGraph(p->getDest(), hole_);
    Node nexthop = findGreedyRoutingNextHop(p->getAnchor_points(0));
    while (nexthop.address().isUnspecified()) {  //TODO: note about isUnspecified(), because may be we didn't set L3Address
        p->setAnchor_points(0, graph->traceBack(p->getAnchor_points(0)));
        if (p->getAnchor_points(0) == graph->endpoint()) break;
        nexthop = findGreedyRoutingNextHop(p->getAnchor_points(0));
    }
    delete graph;
}

void NHR::bypassHole(NHRDataPacket *p, Point source, Point dest, std::vector<BoundaryNode> scaleOctagon, Point center) {
    int si1, si2, di1, di2;
    std::vector<Point> aps;

    findLimitAnchorPoint(source, scaleOctagon, center, si2, si1);
    findLimitAnchorPoint(dest, scaleOctagon, center, di1, di2);

    Point ms = G::midpoint(scaleOctagon[si1], scaleOctagon[si2]);
    Point md = G::midpoint(scaleOctagon[di1], scaleOctagon[di2]);
    Line mm = G::line(ms, md);
    if (G::position(scaleOctagon[si1], mm) > 0) {
        int tmp = si2;
        si2 = si1;
        si1 = tmp;
    }

    if (G::position(scaleOctagon[di1], mm) > 0) {
        int tmp = di2;
        di2 = di1;
        di1 = tmp;
    }

    // octagon order: counter clockwise
    // si -> di: counter clockwise
    // si2 -> di2: clockwise
    if (di1 < si1) di1 += 8;
    if (si2 < di2) si2 += 8;

    double length = 0;
    double dis = 0;

    // double scaleOctagon
    for (unsigned int i = 0; i < 8; ++i) {
        scaleOctagon.push_back(scaleOctagon[i]);
    }

    // s - si1 - di1 - d
    dis = G::distance(source, scaleOctagon[si1]);
    for (int i = si1; i < di1; i++) {
        dis += G::distance(scaleOctagon[i], scaleOctagon[i + 1]);
    }
    dis += G::distance(scaleOctagon[di1], dest);
    length = dis;

    for (int i = di1; i >= si1; --i) {
        aps.push_back(scaleOctagon[i]);
    }

    // s - sp - si2 - i2 - i4 - di2 - dp - d
    dis = G::distance(source, scaleOctagon[si2]);
    for (int i = di2; i < si2; ++i) {
        dis += G::distance(scaleOctagon[i], scaleOctagon[i+1]);
    }
    dis += G::distance(scaleOctagon[di2], dest);
    if (dis < length) {
        std::vector<Point>().swap(aps);
        for (int i = di2; i <= si2; ++i) {
            aps.push_back(scaleOctagon[i]);
        }
    }

    // update routing table
    for (std::vector<Point>::iterator it = aps.begin(); it != aps.end(); ++it) {
        int n = p->getAp_index();
        p->setAp_index(n+1);
        p->setAnchor_points(p->getAp_index(), *it);
    }
}

bool NHR::determineOctagonAnchorPoints(NHRDataPacket* p) {
    // calculate dest endpoint
    p->setAnchor_points(0, calculateDestEndpoint(p->getDest()));

    // if sd doesnt intersect with the hole -> go by GPSR set ap_index = 0)
    if (!sdPolygonIntersect(p)) {
        return false;
    }
    // else calculate the scale octagon

    // random I
    double scale_factor;
    Point I;
    I.x_ = 0;
    I.y_ = 0;
    double fr = 0;
    for (unsigned int i = 0; i < octagon_hole_.size(); i++) {
        int ra = uniform(1, INT_MAX);
        I.x_ += octagon_hole_[i].x_ * ra;
        I.y_ += octagon_hole_[i].y_ * ra;
        fr += ra;
    }

    I.x_ = I.x_ / fr;
    I.y_ = I.y_ / fr;

    double dis = G::distance(I, octagon_hole_[0]);
    for (unsigned int i = 1; i < octagon_hole_.size(); i++) {
        double tmp = G::distance(I, octagon_hole_[i]);
        if (tmp > dis) {
            dis = tmp;
        }
    }

    scale_factor = (dis + delta_ * range) / dis;

    // scale hole by I and scale_factor
    std::vector<BoundaryNode> scaleHole;

    for (unsigned int i = 0; i < octagon_hole_.size(); i++) {
        BoundaryNode newPoint;
        newPoint.x_ = scale_factor * octagon_hole_[i].x_ + (1 - scale_factor) * I.x_;
        newPoint.y_ = scale_factor * octagon_hole_[i].y_ + (1 - scale_factor) * I.y_;
        scaleHole.push_back(newPoint);
    }
    dumpScalePolygon(scaleHole, I);

    // generate new anchor points
    bypassHole(p, *mySelf, p->getAnchor_points(0), scaleHole, I);
    return true;
}

/*-------------- Dump ----------------*/
void NHR::dump() {
    FILE *fp = fopen("Dump.tr", "a+");
    for (std::vector<BoundaryNode>::iterator it = hole_.begin(); it != hole_.end(); ++it) {
        fprintf(fp, "%d\t%f\t%f\t%d\n", (*it).id_, (*it).x_, (*it).y_, (*it).is_convex_hull_boundary_);
    }
    for (std::vector<BoundaryNode>::iterator it = octagon_hole_.begin(); it != octagon_hole_.end(); ++it) {
            fprintf(fp, "%d\t%f\t%f\t%d\n", (*it).id_, (*it).x_, (*it).y_, (*it).is_convex_hull_boundary_);
        }
    fclose(fp);
}

void NHR::dumpBroadcastRegion() {
    FILE *fp = fopen("BroadcastRegion.tr", "a+");
    fprintf(fp, "%d\t%f\t%f\n", mySelf->id(), mySelf->x_, mySelf->y_);
    fclose(fp);
}

void NHR::dumpScalePolygon(std::vector<BoundaryNode> scale, Point center) {
    FILE *fp = fopen("ScalePolygon.tr", "a+");
    fprintf(fp, "%f\t%f\n\n", center.x_, center.y_);
    for (unsigned int i = 0; i < scale.size(); ++i) {
        fprintf(fp, "%f\t%f\n", scale[i].x_, scale[i].y_);
    }
    fprintf(fp, "\n");
    fclose(fp);
}
} //namespace
