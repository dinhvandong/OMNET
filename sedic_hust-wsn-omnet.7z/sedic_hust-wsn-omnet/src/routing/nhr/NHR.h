//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#ifndef __WSN_NHR_H_
#define __WSN_NHR_H_

#include <BoundHole.h>
#include <NHRMessage_m.h>
#include <algorithm>
#include <vector>
#include <set>
#include <map>

#define MIN_CAVE_VERTEX 10

using namespace std;
using namespace omnetpp;

namespace wsn {

struct BoundaryNode : Point {
       int id_;
       bool is_convex_hull_boundary_;

       // comparison is done first on y coordinate and then on x coordinate
       bool operator<(BoundaryNode n2) {
           return y_ == n2.y_ ? x_ < n2.x_ : y_ < n2.y_;
       }
   };

struct COORDINATE_ORDER {
    bool operator()(const BoundaryNode *a, const BoundaryNode *b) const {
        return a->y_ == b->y_ ? a->x_ < b->x_ : a->y_ < b->y_;
    }
};

// used for sorting points according to polar order w.r.t the pivot
// used in convex hull algorithm
struct POLAR_ORDER {
    POLAR_ORDER(struct BoundaryNode p) { this->pivot = p; }

    bool operator()(const BoundaryNode *a, const BoundaryNode *b) const {
        int order = G::orientation(pivot, *a, *b);
        if (order == 0)
            return G::distance(pivot, *a) < G::distance(pivot, *b);
        return (order == 2);
    }

    struct BoundaryNode pivot;
};


class NHR : public BoundHole
{
public:
    NHR();
    ~NHR();
private:
    bool isSource;    // temporary solution

    vector<BoundaryNode> hole_;
    vector<BoundaryNode> octagon_hole_;

    cMessage* nhr_data_timer_;

    double delta_; // scale factor
    Point endpoint_; // endpoint of the node
    bool isPivot_; // node that can go straight to the gate

    virtual void recvSelfMessage(cMessage* message) override;
    virtual void recvMessage(cPacket* packet, IPInfo* ipInfo) override;

    void createPolygonHole(PolygonHole &hole);

    vector<BoundaryNode> determineConvexHull();

    void approximateHole(vector<BoundaryNode>);

    void broadcastHCI();

    void recvHCI(BoundHolePacket *p, IPInfo *ctrlInfo);

    bool canBroadcast();

    void calculateScaleFactor(double d);

    double distanceToPolygon(PolygonHole p);

    void sendData();

    void recvData(NHRDataPacket *p);

    Point calculateDestEndpoint(Point );

    bool determineOctagonAnchorPoints(NHRDataPacket *);

    bool sdPolygonIntersect(NHRDataPacket *);

    void bypassHole(NHRDataPacket *, Point, Point, vector<BoundaryNode>, Point);

    void findLimitAnchorPoint(Point, vector<BoundaryNode>, Point, int &, int &);

    void findViewLimitVertices(Point, vector<BoundaryNode>, int &, int &);

    bool isPointInsidePolygon(Point, vector<BoundaryNode>);

    void routeToDest(NHRDataPacket *p);

    void dump();

    void dumpBroadcastRegion();

    void dumpScalePolygon(vector<BoundaryNode>, Point);

protected:
    void init() override;
    void getLocation();
    void startUp() override;
    void setupTimer() override;
};

} //namespace

#endif
