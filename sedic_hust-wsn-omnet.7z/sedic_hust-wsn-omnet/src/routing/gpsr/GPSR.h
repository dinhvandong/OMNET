/*
 * GPSR.h
 *
 *  Created on: Jan 2, 2017
 *      Author: user
 */

#ifndef ROUTING_GPSR_GPSR_H_
#define ROUTING_GPSR_GPSR_H_

#include <Common.h>
#include <RoutingBaseAlgorithm.h>
#include <src/routing/gpsr/GPSRMessage_m.h>

using namespace inet;

namespace wsn {

class INET_API GPSR: public RoutingBaseAlgorithm {
public:
	GPSR();
	~GPSR();

	// routing info
	RoutingInfo* createRoutingInfo() override;
	// Returns the length of the header in bytes.
	int computeOptionLength() override;
	// handling data
	Node routing(RoutingInfo* routingInfo) override;

	// GPSR
	L3Address greedyForward(GPSROption *option);
	L3Address periForward(GPSROption *option);

	Point getNeighborPosition(const L3Address& address) const;
    std::vector<Node> getPlanarNeighbors();
    L3Address getNextPlanarNeighborCounterClockwise(const L3Address& startNeighborAddress, double startNeighborAngle);
private:
    Node getNodeByAddress(L3Address addr);
};

} /* namespace wsn */

#endif /* ROUTING_GPSR_GPSR_H_ */
