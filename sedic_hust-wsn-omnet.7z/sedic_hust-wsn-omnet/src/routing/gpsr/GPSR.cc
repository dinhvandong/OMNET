/*
 * GPSR.cc
 *
 *  Created on: Jan 2, 2017
 *      Author: user
 */

#include <src/routing/gpsr/GPSR.h>
#include <Common.h>
#include <GeoMathHelper.h>

using namespace inet;
using namespace omnetpp;
using namespace wsn;

namespace wsn {
Define_Module(GPSR);

GPSR::GPSR() {
}
GPSR::~GPSR() {
}

RoutingInfo* GPSR::createRoutingInfo() {
	GPSROption *option = new GPSROption();
	option->setRoutingMode(GPSRMode::GPSR_GREEDY);
	option->setDestinationPosition(*dest);
	option->setLength(computeOptionLength());
	return option;
}

int GPSR::computeOptionLength() {
	// routingMode
	int routingModeBytes = 1;
	// destinationPosition, perimeterRoutingStartPosition, perimeterRoutingForwardPosition
	int positionsBytes = 3 * 2 * 4;
	// currentFaceFirstSenderAddress, currentFaceFirstReceiverAddress, senderAddress
	int addressesBytes = 3 * getSelfAddress().getAddressType()->getAddressByteLength();
	// type and length
	int tlBytes = 1 + 1;

	return tlBytes + routingModeBytes + positionsBytes + addressesBytes;
}

Node GPSR::routing(RoutingInfo* routingInfo) {
	GPSROption *option = check_and_cast_nullable<GPSROption*>(routingInfo);
	L3Address nextHop;
	switch (option->getRoutingMode()) {
	case GPSRMode::GPSR_GREEDY:
		nextHop = greedyForward(option);
		break;
	case GPSRMode::GPSR_PERIMETER:
		nextHop = periForward(option);
		break;
	default:
		throw cRuntimeError("Unknown routing mode");
	}
	option->setSenderAddress(getSelfAddress());
	return getNodeByAddress(nextHop);
}

L3Address GPSR::greedyForward(GPSROption *option) {
	Node bestNb = findGreedyRoutingNextHop(option->getDestinationPosition());
	if (bestNb.address().isUnspecified()) {
		option->setRoutingMode(GPSRMode::GPSR_PERIMETER);
		option->setPerimeterRoutingStartPosition(*mySelf);
		option->setCurrentFaceFirstSenderAddress(getSelfAddress());
		option->setCurrentFaceFirstReceiverAddress(L3Address());
		return periForward(option);
	}
	return bestNb.address();
}

L3Address GPSR::periForward(GPSROption *option) {
	Point perimeterRoutingStartPosition = option->getPerimeterRoutingStartPosition();
	Point destinationPosition = option->getDestinationPosition();
	double selfDistance = G::distance(*mySelf, destinationPosition);
	double perimeterRoutingStartDistance = G::distance(perimeterRoutingStartPosition, destinationPosition);

	if (selfDistance < perimeterRoutingStartDistance) {
		option->setRoutingMode(GPSR_GREEDY);
		option->setPerimeterRoutingStartPosition(Point());
		option->setPerimeterRoutingForwardPosition(Point());
		return greedyForward(option);
	} else {
		L3Address& firstSenderAddress = option->getCurrentFaceFirstSenderAddress();
		L3Address& firstReceiverAddress = option->getCurrentFaceFirstReceiverAddress();
		L3Address nextNeighborAddress = option->getSenderAddress();
		bool hasIntersection;
		do {
			if (nextNeighborAddress.isUnspecified()) {
				double destinationAngle = G::getVectorAngle(destinationPosition, *mySelf);
				nextNeighborAddress = getNextPlanarNeighborCounterClockwise(nextNeighborAddress, destinationAngle);
			} else {
				double neighborAngle = G::getVectorAngle(getNeighborPosition(nextNeighborAddress), *mySelf);
				nextNeighborAddress = getNextPlanarNeighborCounterClockwise(nextNeighborAddress, neighborAngle);
			}
			if (nextNeighborAddress.isUnspecified()) {
				break;
			}
			Point nextNeighborPosition = getNeighborPosition(nextNeighborAddress);
			Point intersection = G::intersectSections(perimeterRoutingStartPosition, destinationPosition, *mySelf, nextNeighborPosition);
			hasIntersection = !std::isnan(intersection.x());
			if (hasIntersection) {
				option->setCurrentFaceFirstSenderAddress(getSelfAddress());
				option->setCurrentFaceFirstReceiverAddress(L3Address());
			}
		} while (hasIntersection);
		if (firstSenderAddress == getSelfAddress() && firstReceiverAddress == nextNeighborAddress) {
			return L3Address();
		} else {
			if (option->getCurrentFaceFirstReceiverAddress().isUnspecified())
				option->setCurrentFaceFirstReceiverAddress(nextNeighborAddress);
			return nextNeighborAddress;
		}
	}
}

Point GPSR::getNeighborPosition(const L3Address& address) const {
	for (auto nb : nbList) {
		if (nb.address() == address) {
			return nb;
		}
	}
	return Point(NaN, NaN);
}

Node GPSR::getNodeByAddress(L3Address addr) {
    for (auto nb : nbList) {
        if (nb.address() == addr) {
            return nb;
        }
    }
    return Node(NaN, L3Address(), NaN, NaN);
}
L3Address GPSR::getNextPlanarNeighborCounterClockwise(const L3Address& startNeighborAddress, double startNeighborAngle) {
	L3Address bestNbAddress = startNeighborAddress;
	double bestNbAngleDifference = 2 * M_PI;
	std::vector<Node> planarNbs = getPlanarNeighbors();
	for (auto & nb : planarNbs) {
		double nbAngle = G::getVectorAngle(nb, *mySelf);
		double nbAngleDifference = nbAngle - startNeighborAngle;
		if (nbAngleDifference < 0) {
			nbAngleDifference += 2 * M_PI;
		}
		if (nbAngleDifference != 0 && nbAngleDifference < bestNbAngleDifference) {
			bestNbAngleDifference = nbAngleDifference;
			bestNbAddress = nb.address();
		}
	}
	return bestNbAddress;
}

// RNG mode
std::vector<Node> GPSR::getPlanarNeighbors() {
	std::vector<Node> planarNeighbors;
	for (auto it = nbList.begin(); it != nbList.end(); it++) {
		const Node& nb = *it;
		double nbDistance = G::distance(nb, mySelf);
		for (auto & nb2 : nbList) {
			double witnessDistance = G::distance(nb2, mySelf);
			double nbWitnessDistance = G::distance(nb2, nb);
			if (*it == nb2) {
				continue;
			} else if (nbDistance > std::max(witnessDistance, nbWitnessDistance)) {
				break;
			}
		}
		planarNeighbors.push_back(*it);
	}
	return planarNeighbors;
}

} /* namespace wsn */
