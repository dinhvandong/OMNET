/*
 * RoutingBaseAlgorithm.h
 *
 *  Created on: Dec 31, 2016
 *      Author: user
 */

#ifndef ROUTING_BASE_ROUTINGBASEALGORITHM_H_
#define ROUTING_BASE_ROUTINGBASEALGORITHM_H_

#include <IL3AddressType.h>
#include <InitStages.h>
#include <L3Address.h>
#include <Node.h>
#include <omnetpp/csimplemodule.h>
#include <vector>
#include <NodeStatus.h>
#include <IMobility.h>
#include <INetfilter.h>
#include <IRoutingTable.h>
#include <RBAMessage_m.h>
#include <UDPPacket.h>

using namespace wsn;
using namespace inet;
using namespace omnetpp;

namespace wsn {

class INET_API RoutingBaseAlgorithm: public cSimpleModule, public INetfilter::IHook {

private:
	double helloPeriod;

	cMessage *helloTimer;

	cModule *host = nullptr;
	const char *interfaces = nullptr;
	IMobility *mobility = nullptr;
	IL3AddressType *addressType = nullptr;
	IInterfaceTable *interfaceTable = nullptr;
	INetfilter *networkProtocol = nullptr;
	IRoutingTable *routingTable = nullptr;

protected:
	double range;

	std::vector<Node> nbList;
	Node *mySelf, *dest;

private:
	int numInitStages() const override {
		return NUM_INIT_STAGES;
	}
	virtual void initialize(int stage) override;
	virtual void handleMessage(cMessage *msg) override;

	// configuration
	void configureInterfaces();

	// routing information
	void setRoutingOptionOnNetworkDatagram(INetworkDatagram *datagram);
	RoutingInfo* findRoutingOptionInNetworkDatagram(INetworkDatagram *datagram);

	// routing & net filter
	Result routeDatagram(INetworkDatagram *datagram, const InterfaceEntry *& outputInterfaceEntry, L3Address& nextHop);
	Result datagramPreRoutingHook(INetworkDatagram *datagram, const InterfaceEntry *inputInterfaceEntry, const InterfaceEntry *& outputInterfaceEntry, L3Address& nextHop)
			override;
	Result datagramForwardHook(INetworkDatagram *datagram, const InterfaceEntry *inputInterfaceEntry, const InterfaceEntry *& outputInterfaceEntry, L3Address& nextHop)
			override {
		return ACCEPT;
	}
	Result datagramPostRoutingHook(INetworkDatagram *datagram, const InterfaceEntry *inputInterfaceEntry, const InterfaceEntry *& outputInterfaceEntry, L3Address& nextHop)
			override {
		return ACCEPT;
	}
	Result datagramLocalInHook(INetworkDatagram *datagram, const InterfaceEntry *inputInterfaceEntry)
			override {
		return ACCEPT;
	}
	Result datagramLocalOutHook(INetworkDatagram *datagram, const InterfaceEntry *& outputInterfaceEntry, L3Address& nextHop)
			override;

public:
	RoutingBaseAlgorithm();
	~RoutingBaseAlgorithm();

protected:
	virtual void finish() override;
	virtual void init();
	virtual void startUp();
	virtual void setupTimer();

	// address
	L3Address getSelfAddress() const;
	L3Address broadcastAddress() {
		return addressType->getLinkLocalManetRoutersMulticastAddress();
	}

	// neighbor
	virtual void addNeighbor(Node &node);
	Node* getNeighbor(int id);

	void sendUDPPacket(cPacket *msg, L3Address destAddr, int ttl, double delay);

	// handling messages
	virtual void recvSelfMessage(cMessage *message);
	virtual void recvMessage(cPacket*packet, IPInfo *ipInfo);

	// routing info
	virtual RoutingInfo* createRoutingInfo();
	// Returns the length of the header in bytes.
	virtual int computeOptionLength();

	// handling data
	virtual Node routing(RoutingInfo* routingInfo);
	Node findGreedyRoutingNextHop(Point &dest);

	// dump
	void dumpNeighbors();

private:

    // startup
    void getLocation();

	// handling hello timer
	void scheduleHelloTimer();
	void processHelloTimer();

	// handling hello
	RBAHello *createHello();
	void sendHello(RBAHello *msg, double delay);
	void recvHello(RBAHello *msg);

	IPInfo* getIPInfo(cMessage *msg);
	void recvMessageInternal(cMessage *message);
};

} /* namespace wsn */

#endif /* ROUTING_BASE_ROUTINGBASEALGORITHM_H_ */
