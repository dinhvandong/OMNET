#include <Common.h>
#include <IInterfaceTable.h>
#include <InterfaceEntry.h>
#include <INetworkProtocolControlInfo.h>
#include <IPProtocolId_m.h>
#include <IPSocket.h>
#include <ModuleAccess.h>
#include <NotifierConsts.h>
#include <IPv4Datagram.h>
#include <omnetpp.h>
#include <omnetpp/ccomponent.h>
#include <omnetpp/cexception.h>
#include <omnetpp/checkandcast.h>
#include <omnetpp/clog.h>
#include <omnetpp/cmessage.h>
#include <omnetpp/cnamedobject.h>
#include <omnetpp/cobjectfactory.h>
#include <omnetpp/cpar.h>
#include <omnetpp/cpatternmatcher.h>
#include <omnetpp/csimulation.h>
#include <omnetpp/regmacros.h>
#include <omnetpp/simtime.h>
#include <RoutingBaseAlgorithm.h>
#include <GeoMathHelper.h>
#include <UDPPacket.h>
#include <cmath>
#include <iostream>
#include <iterator>
#include <utility>
#include <BoundHoleMessage_m.h>

using namespace omnetpp;
using namespace inet;

namespace wsn {
Define_Module(RoutingBaseAlgorithm);

RoutingBaseAlgorithm::RoutingBaseAlgorithm() {
}

RoutingBaseAlgorithm::~RoutingBaseAlgorithm() {
}

void RoutingBaseAlgorithm::initialize(int stage) {
	cSimpleModule::initialize(stage);

	if (stage == INITSTAGE_LOCAL) {
		// context
		host = getContainingNode(this);
		interfaceTable = getModuleFromPar<IInterfaceTable>(par("interfaceTableModule"), this);
		interfaces = par("interfaces");
		mobility = check_and_cast<IMobility *>(host->getSubmodule("mobility"));
		routingTable = getModuleFromPar<IRoutingTable>(par("routingTableModule"), this);
		networkProtocol = getModuleFromPar<INetfilter>(par("networkProtocolModule"), this);
		init();
	} else if (stage == INITSTAGE_ROUTING_PROTOCOLS) {
		IPSocket socket(gate("gateOut"));
		socket.registerProtocol(IP_PROT_MANET);
		addressType = getSelfAddress().getAddressType();
		networkProtocol->registerHook(0, this);
		configureInterfaces();
		startUp();
		getLocation();
		//init(); // TODO: for test
		setupTimer();
	}
}

void RoutingBaseAlgorithm::handleMessage(cMessage *message) {
	if (message->isSelfMessage()) recvSelfMessage(message);
	else recvMessageInternal(message);
}

void RoutingBaseAlgorithm::finish() {
	dumpNeighbors();
}

//
// Startup configurations
//

void RoutingBaseAlgorithm::init() {
	helloPeriod = par("helloPeriod");
	range = par("range");
}

void RoutingBaseAlgorithm::startUp() {
	FILE *f = fopen("Trace.tr", "w");
	fclose(f);
	f = fopen("Neighbors.tr", "w");
	fclose(f);
}

void RoutingBaseAlgorithm::configureInterfaces() {
	cPatternMatcher interfaceMatcher(interfaces, false, true, false);
	for (int i = 0; i < interfaceTable->getNumInterfaces(); i++) {
		InterfaceEntry *interfaceEntry = interfaceTable->getInterface(i);
		if (interfaceEntry->isMulticast() && interfaceMatcher.matches(interfaceEntry->getName()))
			interfaceEntry->joinMulticastGroup(addressType->getLinkLocalManetRoutersMulticastAddress());
	}
}

L3Address RoutingBaseAlgorithm::getSelfAddress() const {
	return routingTable->getRouterIdAsGeneric();
}

void RoutingBaseAlgorithm::getLocation() {
	mySelf = new Node(par("ID"), getSelfAddress(), mobility->getCurrentPosition().x, mobility->getCurrentPosition().y);

	double x = par("destX");
	double y = par("destY");
	dest = new Node(x, y);
}

void RoutingBaseAlgorithm::setupTimer() {
	helloTimer = new cMessage("HelloTimer");
	scheduleAt(simTime() + 1, helloTimer);
}

//
// Handle messages
//

void RoutingBaseAlgorithm::recvSelfMessage(cMessage *message) {
	if (message == helloTimer) {
		processHelloTimer();
	} else {
		throw cRuntimeError("Unknown self message");
	}
}

void RoutingBaseAlgorithm::recvMessageInternal(cMessage *message) {
	if (dynamic_cast<UDPPacket *>(message)) {
		UDPPacket* packet = static_cast<UDPPacket *>(message);
		cPacket *encapsulatedPacket = packet->decapsulate();
		recvMessage(encapsulatedPacket, getIPInfo(message));
		delete packet;
	} else {
		throw cRuntimeError("Unknown message");
	}
}

void RoutingBaseAlgorithm::recvMessage(cPacket *packet, IPInfo *ipInfo) {
	if (dynamic_cast<RBAHello *>(packet)) {
		recvHello(static_cast<RBAHello *>(packet));
	} else {
		throw cRuntimeError("Unknown UDP packet");
	}
}

IPInfo* RoutingBaseAlgorithm::getIPInfo(cMessage *msg) {
	if (dynamic_cast<UDPPacket *>(msg)) {
		return dynamic_cast<IPInfo *>(msg->getControlInfo());
	}
	return nullptr;
}

void RoutingBaseAlgorithm::sendUDPPacket(cPacket *msg, L3Address destAddr, int ttl, double delay) {
	INetworkProtocolControlInfo *ctrlInfo = addressType->createNetworkProtocolControlInfo();
	ctrlInfo->setTransportProtocol(IP_PROT_MANET);
	ctrlInfo->setDestinationAddress(destAddr);
	ctrlInfo->setSourceAddress(getSelfAddress());
	ctrlInfo->setHopLimit(ttl);

	UDPPacket *pkt = new UDPPacket(msg->getName());
	pkt->encapsulate(msg);
	pkt->setSourcePort(UDP_PORT);
	pkt->setDestPort(UDP_PORT);
	pkt->setControlInfo(dynamic_cast<cObject*>(ctrlInfo));

	if (delay == 0) send(pkt, "gateOut");
	else sendDelayed(pkt, delay, "gateOut");
}

//
// HELLO message
//

void RoutingBaseAlgorithm::scheduleHelloTimer() {
	if (helloPeriod > 0) scheduleAt(simTime() + helloPeriod, helloTimer);
	else cancelAndDelete(helloTimer);
}

void RoutingBaseAlgorithm::processHelloTimer() {
	sendHello(createHello(), mySelf->id() * 0.01);
	scheduleHelloTimer();
}

RBAHello* RoutingBaseAlgorithm::createHello() {
	RBAHello *pkt = new RBAHello("Hello");
	pkt->setNodeInfo(*mySelf);
	return pkt;
}

void RoutingBaseAlgorithm::sendHello(RBAHello *msg, double delay) {
	sendUDPPacket(msg, broadcastAddress(), 1, delay);
}

void RoutingBaseAlgorithm::recvHello(RBAHello *msg) {
	auto nb = msg->getNodeInfo();
	if (G::distance(nb, mySelf) <= this->range) {
		addNeighbor(msg->getNodeInfo());
	}
}

void RoutingBaseAlgorithm::addNeighbor(Node &node) {
	if (getNeighbor(node.id()) == NULL) {
		nbList.push_back(node);
	}
}

Node* RoutingBaseAlgorithm::getNeighbor(int id) {
	for (unsigned int i = 0; i < nbList.size(); i++) {
		if (nbList[i].id() == id) {
			return &nbList[i];
		}
	}
	return NULL;
}

//
// netfilter
//

INetfilter::IHook::Result RoutingBaseAlgorithm::datagramPreRoutingHook(INetworkDatagram *datagram, const InterfaceEntry *inputInterfaceEntry, const InterfaceEntry *& outputInterfaceEntry, L3Address& nextHop) {
	Enter_Method("datagramPreRoutingHook");
	const L3Address& destination = datagram->getDestinationAddress();
	if (destination.isMulticast() || destination.isBroadcast() || routingTable->isLocalAddress(destination)) {
		return ACCEPT;
	}
	else {
		return routeDatagram(datagram, outputInterfaceEntry, nextHop);
	}
}

INetfilter::IHook::Result RoutingBaseAlgorithm::datagramLocalOutHook(INetworkDatagram *datagram, const InterfaceEntry *& outputInterfaceEntry, L3Address& nextHop) {
	Enter_Method("datagramLocalOutHook");
	const L3Address& destination = datagram->getDestinationAddress();
	if (destination.isMulticast() || destination.isBroadcast() || routingTable->isLocalAddress(destination)) {
		return ACCEPT;
	}
	else {

		// hacky, hacky, hack!!!
		if (datagram->getTransportProtocol() == IP_PROT_MANET) { // in case we don't use udpBasicApp, i.e. packet generate by our layer
			nextHop = destination;
			return ACCEPT;
		} else if (datagram->getTransportProtocol() == IP_PROT_UDP) { // data packet (udpBasicApp)
			// actual call our routing algorithm
			setRoutingOptionOnNetworkDatagram(datagram);
			return routeDatagram(datagram, outputInterfaceEntry, nextHop);
		} else { //TODO: why still receive ICMP?
		    return DROP;
			//throw cRuntimeError("Unknown transport protocol");
		}
	}
}

//
// routing
//

INetfilter::IHook::Result RoutingBaseAlgorithm::routeDatagram(INetworkDatagram *datagram, const InterfaceEntry *& outputInterfaceEntry, L3Address& nextHop) {
	auto routingInfo = findRoutingOptionInNetworkDatagram(datagram);
	nextHop = routing(routingInfo).address();
	if (nextHop.isUnspecified()) {
		return DROP;
	} else {
		outputInterfaceEntry = interfaceTable->getInterface(1);
		return ACCEPT;
	}
}

void RoutingBaseAlgorithm::setRoutingOptionOnNetworkDatagram(INetworkDatagram *datagram) {
	cPacket *networkPacket = check_and_cast<cPacket *>(datagram);
	auto routingInfo = createRoutingInfo();
	routingInfo->setType(WSN_ROUTING);
	if (dynamic_cast<IPv4Datagram *>(networkPacket)) {
		IPv4Datagram *dgram = static_cast<IPv4Datagram *>(networkPacket);
		int oldHlen = dgram->calculateHeaderByteLength();
		ASSERT(dgram->getHeaderLength() == oldHlen);
		dgram->addOption(routingInfo);
		int newHlen = dgram->calculateHeaderByteLength();
		dgram->setHeaderLength(newHlen);
		dgram->addByteLength(newHlen - oldHlen);
		dgram->setTotalLengthField(dgram->getTotalLengthField() + newHlen - oldHlen);
	}
}

RoutingInfo* RoutingBaseAlgorithm::findRoutingOptionInNetworkDatagram(INetworkDatagram *datagram) {
	cPacket *networkPacket = check_and_cast<cPacket *>(datagram);
	RoutingInfo *routingInfo = nullptr;

	if (dynamic_cast<IPv4Datagram *>(networkPacket)) {
		IPv4Datagram *dgram = static_cast<IPv4Datagram *>(networkPacket);
		routingInfo = dgram->findOptionByType(WSN_ROUTING);
	}
	return routingInfo;
}

//
// override routing helpers
//

RoutingInfo* RoutingBaseAlgorithm::createRoutingInfo() {
	RBAOption *rbaOption = new RBAOption();
	rbaOption->setDestination(*dest);
	rbaOption->setLength(computeOptionLength());
	return rbaOption;
}

int RoutingBaseAlgorithm::computeOptionLength() {
	return 2 * sizeof(double) + 2;
}

Node RoutingBaseAlgorithm::routing(RoutingInfo* routingInfo) {
	RBAOption *rbaOption = check_and_cast_nullable<RBAOption *>(routingInfo);
	Node bestNb = findGreedyRoutingNextHop(rbaOption->getDestination());
	return bestNb;
}

Node RoutingBaseAlgorithm::findGreedyRoutingNextHop(Point &dest) {
	Node bestNeighbor;
	double bestDistance = G::distance(mySelf, dest);
	for (auto& nb : nbList) {
		double neighborDistance = G::distance(nb, dest);
		if (neighborDistance < bestDistance) {
			bestDistance = neighborDistance;
			bestNeighbor = nb;
		}
	}
	return bestNeighbor;
}

//
// dump
//

void RoutingBaseAlgorithm::dumpNeighbors() {
	FILE *f = fopen("Neighbors.tr", "a");
	fprintf(f, "%d\t%f\t%f\t", mySelf->id(), mySelf->x(), mySelf->y());
	for (unsigned int i = 0; i < nbList.size(); i++) {
		fprintf(f, "%d,", nbList[i].id());
	}
	fprintf(f, "\n");
	fclose(f);
}

}
