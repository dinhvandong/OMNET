//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#ifndef __WSN_GPSROUTING_H_
#define __WSN_GPSROUTING_H_

#include <INETDefs.h>
#include <Node.h>
#include <RoutingBaseAlgorithm.h>
#include <GPSRoutingMessage_m.h>
#include <vector>

using namespace inet;

namespace wsn {

class INET_API GPSRouting : public RoutingBaseAlgorithm
{
public:
    GPSRouting();
    ~GPSRouting();

protected:

    // create header info: packet's attribute of GPSR algorithm
    RoutingInfo* createRoutingInfo() override;

    int computeOptionLength() override;

    // handling data message, return next hop's address
    Node routing(RoutingInfo* routingInfo) override;

private:
    std::vector<Node> planarGraph();  //using RNG
    Point getNb(L3Address a);
    Node rightHandForward(GPSRDataHDR *p, Point prev);
    //check if LpD intersect the edge between current & next hop. If that, change to next face
    Node faceChange(GPSRDataHDR *p, Node nextHop);
    Node periForward(GPSRDataHDR *p);
    Node greedyForward(GPSRDataHDR *p);
};

} //namespace wsn

#endif
