//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#include <GPSRouting.h>
#include <Common.h>
#include <GeoMathHelper.h>

namespace wsn {

Define_Module(GPSRouting);

GPSRouting::GPSRouting() {
}
GPSRouting::~GPSRouting() {
}

RoutingInfo* GPSRouting::createRoutingInfo() {
    GPSRDataHDR* hdr = new GPSRDataHDR();
    hdr->setDest(*dest);
    hdr->setMode(Greedy);
    hdr->setLength(computeOptionLength());
    return hdr;
}

int GPSRouting::computeOptionLength() {
    //routing mode
    int routingModeBytes = 1;
    //3 Point
    int pointBytes = 3 * 2 * 4;
    //3 Address
    int addrBytes = 3 * getSelfAddress().getAddressType()->getAddressByteLength();
    //type and length
    int tlBytes = 1 + 1;

    return routingModeBytes + pointBytes + addrBytes + tlBytes;
}

Node GPSRouting::routing(RoutingInfo *routingInfo) {
    GPSRDataHDR* hdr = check_and_cast_nullable<GPSRDataHDR*>(routingInfo);
    Node nextHop;
    switch (hdr->getMode()) {
    case Greedy:
        nextHop = greedyForward(hdr);
        break;
    case Perimeter:
        nextHop = periForward(hdr);
        break;
    default:
        throw cRuntimeError("Unknown routing mode");
    }
    hdr->setPrev(mySelf->address());
    return nextHop;
}

std::vector<Node> GPSRouting::planarGraph() {
    std::vector<Node> planarNeighbors;
    if (nbList.size() >= 2) {
        for (auto it = nbList.begin(); it != nbList.end(); it++) {
            const Node& nb = *it;
            double a = G::distance(nb, mySelf);
            for (auto & nb1 : nbList) {
                double b = G::distance(nb1, mySelf);
                double c = G::distance(nb, nb1);
                if (*it == nb1)
                    continue;
                else if (a > std::max(b, c))
                    break;
            }
            planarNeighbors.push_back(*it);
        }
    }
    return planarNeighbors;
}
Node GPSRouting::greedyForward(GPSRDataHDR* p) {
    Node nextHop = findGreedyRoutingNextHop(p->getDest());
    if (nextHop.address().isUnspecified()) {
        p->setMode(Perimeter);
        p->setPeri(*mySelf);
        p->setFace(*mySelf);
        p->setPrev(mySelf->address());
        p->setFaceSender(mySelf->address());
        nextHop = periForward(p);
        p->setFaceReceiver(nextHop.address());
        return nextHop;
    }
    return nextHop;
}
Node GPSRouting::rightHandForward(GPSRDataHDR* p, Point prev) {
    Node next;
    std::vector<Node> nbs = planarGraph();
    double angle_min = 3 * M_PI;
    for (unsigned int i = 0; i < nbs.size(); i++) {
        if (nbs[i] == prev)
            continue;
        double angle = G::angle(mySelf, &prev, &nbs[i]);
        if (angle < angle_min) {
            angle_min = angle;
            next = nbs[i];
        }
    }
    return next;
}

Node GPSRouting::faceChange(GPSRDataHDR* p, Node nextHop) {
    Point peri_ = p->getPeri();
    Point face_ = p->getFace();
    Point i_;
    bool i = G::intersection(&nextHop, mySelf, &peri_, dest, i_);
    if (i) {
        if (G::distance(i_, dest) < G::distance(face_, dest)) {
            p->setFace(i_);
            nextHop = rightHandForward(p, nextHop);
            nextHop = faceChange(p, nextHop);
            p->setFaceSender(mySelf->address());
            p->setFaceReceiver(nextHop.address());
            p->setPrev(mySelf->address());
        }
    }
    return nextHop;
}

Point GPSRouting::getNb(L3Address a) {
    for(auto nb : nbList) {
        if(nb.address() == a)
            return nb;
    }
    return Point(NaN, NaN);
}
Node GPSRouting::periForward(GPSRDataHDR* p) {
    Node nextHop;

    double selfDistance = G::distance(mySelf, dest);
    double periDistance = G::distance(p->getPeri(), dest);

    if(selfDistance < periDistance) {
        p->setMode(Greedy);
        return greedyForward(p);
    } else {
        Point prev = getNb(p->getPrev());
        nextHop = rightHandForward(p, prev);
        if(p->getFaceSender() == mySelf->address() && p->getFaceReceiver() == nextHop.address()) {
            EV << "Stuck Node!" << endl;
            delete(p);
        } else {
            nextHop = faceChange(p, nextHop);
        }
    }
    return nextHop;
}

} //namespace wsn
