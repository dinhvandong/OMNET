/*
 * BoundHole.cc
 *
 *  Created on: Jan 2, 2017
 *      Author: user
 */

#include <BoundHole.h>
#include <GeoMathHelper.h>
#include <IL3AddressType.h>
#include <INetworkProtocolControlInfo.h>
#include <IPv4ControlInfo.h>
#include <IPProtocolId_m.h>
#include <log.h>
#include <Node.h>
#include <omnetpp/cexception.h>
#include <omnetpp/cpar.h>
#include <omnetpp/csimulation.h>
#include <omnetpp/simtime.h>
#include <UDPPacket.h>
#include <cmath>
#include <cstdio>

using namespace wsn;
using namespace inet;

namespace wsn {
Define_Module(BoundHole);

BoundHole::BoundHole() {
}

BoundHole::~BoundHole() {
}

void BoundHole::init() {
	storageOpt = (BoundHoleStorageMode) (int) par("storageOpt");
	limitMaxHop = (int) par("limitMaxHop");
	limitMinHop = (int) par("limitMinHop");
	RoutingBaseAlgorithm::init();
}

void BoundHole::startUp() {
	FILE *fp;
	fp = fopen("BoundHole.tr", "w");
	fclose(fp);
	RoutingBaseAlgorithm::startUp();
}

void BoundHole::setupTimer() {
	findStuckNodeTimer = new cMessage("StuckNodeTimer");
	scheduleAt(simTime() + par("startTentRule"), findStuckNodeTimer);
	boundHoleTimer = new cMessage("BoundHoleTimer");
	scheduleAt(simTime() + par("startBoundHole"), boundHoleTimer);
	RoutingBaseAlgorithm::setupTimer();
}

void BoundHole::recvSelfMessage(cMessage *message) {
	if (message == findStuckNodeTimer) {
		findStuckAngle();
	} else if (message == boundHoleTimer) {
		sendBoundHole();
	} else {
		RoutingBaseAlgorithm::recvSelfMessage(message);
	}
}

void BoundHole::recvMessage(cPacket*packet, IPInfo *ipInfo) {
	if (dynamic_cast<BoundHolePacket *>(packet)) {
		auto bpkt = static_cast<BoundHolePacket *>(packet);
		if (bpkt->getType() == BOUNDHOLE_BOUNDHOLE) {
			recvBoundHole(ipInfo, bpkt);
		} else if (bpkt->getType() == BOUNDHOLE_REFRESH) {
			recvRefresh(bpkt);
		} else {
			throw cRuntimeError("Unknown BOUNDHOLE type");
		}
	} else {
		RoutingBaseAlgorithm::recvMessage(packet, ipInfo);
	}
}

void BoundHole::addNeighbor(Node &node) {
	if (getNeighbor(node.id()) != NULL) {
		return;
	}
	if (nbList.empty()) {
		nbList.push_back(node);
	} else {
		Angle angle = G::angle(*mySelf, nbList[0], *mySelf, node);
		int i = 0;
		for (i = 0; i + 1 < nbList.size(); i++) {
			if (G::angle(*mySelf, nbList[0], *mySelf, nbList[i + 1]) > angle) {
				nbList.insert(nbList.begin() + i + 1, node);
				break;
			}
		}

		if (i == nbList.size() - 1) {
			nbList.push_back(node);
		}
	}
}

//
// TENT rule
//

void BoundHole::findStuckAngle() {
	if (nbList.size() <= 1) {
		return;
	}

	int i = 0;
	Node nb1 = nbList[i]; //u
	Node nb2 = nbList[i + 1]; //v
	while (i < nbList.size()) {
		Circle circle = G::circumcenter(*mySelf, nb1, nb2);
		Angle a = G::angle(*mySelf, nb1, *mySelf, circle); // upO
		Angle b = G::angle(*mySelf, nb1, *mySelf, nb2); // upv
		Angle c = G::angle(*mySelf, circle, *mySelf, nb2); //Opv

		// if O is outside range of node, nb1 and nb2 create a stuck angle with node
		if (b >= M_PI || (fabs(a) + fabs(c) == fabs(b) && G::distance(mySelf, circle) > range)) {
			stuckAngle_.push_back(StuckAngle(nb1, nb2));
		}
		nb1 = nbList[++i];
		nb2 = nbList[(i + 1) % nbList.size()];
	}
}

//
// BOUNDHOLE
//

void BoundHole::sendBoundHole() {
	for (auto &sa : stuckAngle_) {
		BoundHolePacket *msg = new BoundHolePacket("BoundHole");
		msg->setType(BOUNDHOLE_BOUNDHOLE);
		msg->setSourceId(mySelf->id());
		msg->setPreviousNode(*mySelf);
		msg->getBoundholeNodes().push_back(sa.b_);
		msg->getBoundholeNodes().push_back(*mySelf);
		sendUDPPacket(msg, sa.a_.address(), limitMaxHop, mySelf->id() * 0.01);
	}
}

void BoundHole::recvBoundHole(IPInfo *ctrlInfo, BoundHolePacket *bhh) {
	std::vector<Node> data;
	for (auto nb : bhh->getBoundholeNodes()) {
		data.push_back(nb);
	}

	int pid = bhh->getSourceId();
 	logBoundHoleRecv(pid, mySelf->id());
	// if the boundhole packet has came back to the initial node
	if (bhh->getSourceId() == mySelf->id()) {
		if (ctrlInfo->getHopLimit() > (limitMaxHop - limitMinHop)) {
			logBoundHoleDrop(pid, "SmallHole");
			return; // SmallHole
		} else {
			auto hole = createHole(bhh);
			createPolygonHole(*hole);
			dumpBoundHole(*hole);
			if (storageOpt == BoundHole_Storage_One) {
				broadcastHCI();
			} else {
				sendRefresh(*hole);
			}
			return;
		}
	}

	if (ctrlInfo->getHopLimit() <= 0) {
		logBoundHoleDrop(pid, "DROP_RTR_TTL");
		return; // DROP_RTR_TTL
	}

	Node n = data[0];
	if (n.id() == bhh->getSourceId()) {
		data.erase(data.begin());
	} else {
		n = data[data.size() - 2];
	}
	Node *nb = getNeighborByBoundHole(&bhh->getPreviousNode(), &n);
	if (nb == NULL) {
		logBoundHoleDrop(pid, "DROP_RTR_NO_ROUTE");
		return; // DROP_RTR_NO_ROUTE
	}

	Node temp, next;
	for (int i = 0; i < data.size() - 1; i++) {
		temp = data[i];
		next = data[i + 1];

		if (G::is_intersect2(mySelf, nb, temp, next)) {
			if (G::distance(temp, nb) < range) {
				while (data.size() >= (i + 2)) {
					data.erase(data.begin() + i + 1);
				}
				data.push_back(*nb);
				nb = getNeighborByBoundHole(nb, &temp);
				if (nb == NULL) {
					logBoundHoleDrop(pid, "DROP_RTR_NO_ROUTE");
					return; // DROP_RTR_NO_ROUTE
				}
				continue;
			} else {
				nb = getNeighbor(next.id());
				if (nb == NULL) {
					logBoundHoleDrop(pid, "DROP_RTR_NO_ROUTE");
					return; // DROP_RTR_NO_ROUTE
				}
				continue;
			}
		}
	}

	// if neighbor already send boundhole message to that node
	if (bhh->getSourceId() > mySelf->id()) {
		for (auto sa : stuckAngle_) {
			if (sa.a_.id() == nb->id()) {
				logBoundHoleDrop(pid, "REPEAT");
				return; // REPEAT
			}
		}
	}

	data.push_back(*mySelf);

	BoundHolePacket *msg = new BoundHolePacket("BoundHole");
	msg->setPreviousNode(*mySelf);
	msg->setType(BOUNDHOLE_BOUNDHOLE);
	msg->setSourceId(bhh->getSourceId());
	for (auto &nb : data) {
		msg->getBoundholeNodes().push_back(nb);
	}
	sendUDPPacket(msg, nb->address(), ctrlInfo->getHopLimit(), 0);
}

PolygonHole* BoundHole::createHole(BoundHolePacket *packet) {
	PolygonHole *hole = new PolygonHole(mySelf->id());

	auto data = packet->getBoundholeNodes();
	for (auto &nb : data) {
		hole->addNode(nb);
	}

	return hole;
}

Node* BoundHole::getNeighborByBoundHole(Point *p, Point *prev) {
	Angle max_angle = -1;
	Node* nb = NULL;

	for (auto &temp : nbList) {
		Angle a = G::angle(mySelf, p, mySelf, &temp);
		if (a > max_angle && (!G::is_intersect(mySelf, &temp, p, prev) || (temp.x_ == p->x_ && temp.y_ == p->y_) || (mySelf->x_ == prev->x_ && mySelf->y_ == prev->y_))) {
			max_angle = a;
			nb = &temp;
		}
	}

	return nb;
}

void BoundHole::createPolygonHole(PolygonHole &hole) {
	holeList.push_back(hole);
}

//
// REFRESH
//
void BoundHole::sendRefresh(PolygonHole hole) {
    BoundHolePacket *p = new BoundHolePacket("BoundHoleRefresh");
    std::vector<Node> h = hole.nodeList();
    p->setType(BOUNDHOLE_REFRESH);
    p->setIndex(2);
    p->setSourceId(mySelf->id());
    p->setBoundholeNodes(h);
    sendUDPPacket(p, h[1].address(), h.size() - 1, 0);
}

void BoundHole::recvRefresh(BoundHolePacket* p) {
    int i = p->getIndex();
    std::vector<Node> h = p->getBoundholeNodes();
    if (i < h.size()) {
        auto hole = createHole(p);
        createPolygonHole(*hole);
        p->setIndex(i + 1);
        Node nextHop = h[i];
        sendUDPPacket(p, nextHop.address(), h.size() - i + 1, 0);
    } else
        delete (p);
}

//
// DUMP
//

void BoundHole::dumpBoundHole(PolygonHole &hole) {
	FILE *fp = fopen("BoundHole.tr", "a");
	for (auto nb : hole.nodeList()) {
		fprintf(fp, "%d\t%f\t%f\n", nb.id(), nb.x(), nb.y());
	}
	fprintf(fp, "\n");
	fclose(fp);
}

} /* namespace wsn */
