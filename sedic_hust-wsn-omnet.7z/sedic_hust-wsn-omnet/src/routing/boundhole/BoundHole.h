/*
 * BoundHole.h
 *
 *  Created on: Jan 2, 2017
 *      Author: user
 */

#ifndef ROUTING_BOUNDHOLE_BOUNDHOLE_H_
#define ROUTING_BOUNDHOLE_BOUNDHOLE_H_

#include <Common.h>
#include <RoutingBaseAlgorithm.h>
#include <BoundHoleMessage_m.h>
#include <vector>

namespace wsn {

class BoundHole: public RoutingBaseAlgorithm {
public:
	BoundHole();
	~BoundHole();

private:
	enum BoundHoleStorageMode {
		BoundHole_Storage_All, BoundHole_Storage_One,
	};

	cMessage *boundHoleTimer;
	cMessage *findStuckNodeTimer;

	virtual void recvSelfMessage(cMessage *message) override;
	virtual void recvMessage(cPacket*packet, IPInfo *ipInfo) override;

	void findStuckAngle();

	void sendBoundHole();
	void recvBoundHole(IPInfo *ctrlInfo, BoundHolePacket *bhh);

    void sendRefresh(PolygonHole hole);
    void recvRefresh(BoundHolePacket*);

	Node* getNeighborByBoundHole(Point*p, Point*prev);

	void addNeighbor(Node &node) override;

	void dumpBoundHole(PolygonHole &hole);

protected:
	double storageOpt;
	int limitMaxHop;
	int limitMinHop;

	std::vector<StuckAngle> stuckAngle_;
	std::vector<PolygonHole> holeList;

	void init() override;
	void startUp() override;
	void setupTimer() override;

	PolygonHole* createHole(BoundHolePacket *packet);
	virtual void createPolygonHole(PolygonHole &hole);
	virtual void broadcastHCI() {
	}
	;
};

} /* namespace wsn */

#endif /* ROUTING_BOUNDHOLE_BOUNDHOLE_H_ */
