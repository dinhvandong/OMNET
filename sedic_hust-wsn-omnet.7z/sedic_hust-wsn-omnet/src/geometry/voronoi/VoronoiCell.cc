/*
 * VoronoiCell.cc
 *
 *  Created on: Jan 7, 2017
 *      Author: starlight
 */

#include <voronoi/VoronoiCell.h>

using namespace voronoi;

VoronoiCell::VoronoiCell(VoronoiSite* site) : site(site)
{
}
