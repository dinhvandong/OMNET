/*
 * MainNode.h
 *
 *  Created on: Jul 7, 2017
 *      Author: admin
 */

#ifndef MainNode_H_
#define MainNode_H_

#include <string.h>
#include <omnetpp.h>
#include "Message_m.h"
#define SIMTIME 1

using namespace omnetpp;
class MainNode : public cSimpleModule
{
  public:
    MainNode();
       cMessage *helloTimer;
       void CreateNetworkList();
       std::vector<Node> networkList;
       int numHosts;
       virtual void initialize() override;
       virtual void handleMessage(cMessage *msg) override;

};
/*
 * Xay dung MainNode la node co ban ke thua cSimpleModule
 * Cac node con lai ke thua tren MainNode
 * Duyet theo MainNode
 * Neu cai nao la GreedyNode thi se tinh toan thuat toan dinh tuyet
 * Neu cai nao la MainRoom thi se thuc hien viec nhet thong tin cac node vao
 * :D :D :D
 *
 *
 * */
#endif /* MainNode_H_ */
