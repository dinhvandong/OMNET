/*
 * BaseNode.cc
 *
 *  Created on: Jul 7, 2017
 *      Author: admin
 */

#include <string.h>
#include <omnetpp.h>
#include<BaseNode.h>
#include<Node.h>
#include<Message_m.h>
#include<MainNode.h>
using namespace omnetpp;
using namespace inet;

// The module class needs to be registered with OMNeT++
Define_Module(BaseNode);
BaseNode::BaseNode(){
}
void BaseNode::getNode(){
    // ham getNode xu ly lay thong tin cua BaseNode truoc khi tinh toan trong MainNode
     x_new =(int)par("x") ;
     y_new= (int)par("y");
     id_new= (int)par("id");

}
void BaseNode::init(){
    // lay ra Size cua NetWork dua vao trong file Network
       numHosts = (int )(this->getParentModule()->par("numHosts"));
       mySelf = new Node((int)par("id"), (int)par("x"),(int)par("y"));
       range = par("range");
       dest = new Node((int)par("destX"),(int)par("destY"));
       isSource = par("isSource");
       numHosts = (int)(this->getParentModule()->par("numHosts"));
       dataPeriod = par("dataPeriod");
       FILE *fp = fopen("Trace.tr","w");
       fclose(fp);
       fp = fopen("Neighbors.tr","w");
       fclose(fp);
}
void BaseNode::initialize()
{
    init();
    helloTimer = new cMessage("HelloTimer");
    scheduleAt(simTime()+3,helloTimer);
    if(isSource){
        dataTimer = new cMessage("DataTimer");
        scheduleAt(simTime() + par("startSendData"), dataTimer);
    }
}
void BaseNode::handleMessage(cMessage *msg)
{
    if(msg->isSelfMessage()){
        if(strcmp(msg->getName(),"HelloTimer")==0){
            sendHello();
        }else if (strcmp(msg->getName(),"DataTimer")==0){
            Data *ptk = new Data("Data");
            ptk->setHopCount(0);
            ptk->setDestination(*dest);
            sendData(ptk);
            if(simTime().dbl() < SIMTIME){
                scheduleAt(simTime() + par("dataPeriod"),dataTimer);
            }
        }else{

            throw cRuntimeError("Just self message");
        }
    }
}

void BaseNode::sendHello(){
    MainNode *nH =(MainNode*)(this->getParentModule()->getSubmodule("main",-1));
    networkList = nH->networkList;
    for (auto nH: networkList){
           if(G::distance(mySelf,nH)<= range){
               addNeighbor(nH);
           }
       }
}
void BaseNode::sendData(Data * pkt){
    if (*mySelf == pkt->getDestination()){
        return;
    }
    pkt->setHopCount(pkt->getHopCount() + 1);
    Node* nextHop = getNextHopByGreedy(pkt->getDestination());
    if (nextHop == NULL)
    {
        std::cout<<"sendData DROP";
        FILE *fp = fopen("Trace.tr", "a");
        fprintf(fp, "DROP %d\n", mySelf->id());
        fclose(fp);
    } else
    {

        std::cout<<"sendData SEND";

        BaseNode *nH = (BaseNode*)(this->getParentModule()->getSubmodule("host", nextHop->id()));
        //log - temporary
        FILE *fp = fopen("Trace.tr", "a");
        fprintf(fp, "SEND %d-->%d\n", mySelf->id(), nextHop->id());
        fclose(fp);
        nH->sendData(pkt);
    }
}
Node* BaseNode::getNeighbor(int id){
    for (unsigned int i = 0; i < nbList.size(); i++) {
          if (nbList[i].id() == id) {
              return &nbList[i];
          }
      }
      return NULL;
}

void BaseNode::addNeighbor( Node &node){
    if(node.check== false){
        nbList.push_back(node);
        node.check = true;
    }
}
Node* BaseNode::getNextHopByGreedy(Point &dest){
    Node *bestNeighbor = NULL;
    double bestDistance = G::distance(mySelf, dest);
       for (auto& nb : nbList) {
           double neighborDistance = G::distance(nb, dest);
           if (neighborDistance < bestDistance) {
               bestDistance = neighborDistance;
               bestNeighbor = &nb;
           }
       }
       return bestNeighbor;
}
void BaseNode::dumpNeighbors() {
    FILE *f = fopen("Neighbors.tr", "a");
    fprintf(f, "%d\t%f\t%f\t", mySelf->id(), mySelf->x(), mySelf->y());
    for (unsigned int i = 0; i < nbList.size(); i++) {
        fprintf(f, "%d,", nbList[i].id());
    }
    fprintf(f, "\n");
    fclose(f);
}

void BaseNode::finish() {
    dumpNeighbors();
}
