/*
 * Node.cc
 *
 *  Created on: Jun 27, 2017
 *      Author: admin
 */

#include<Node.h>

#include<GeoMathHelper.h>

Node::Node(){
}

Node::Node(double x, double y){

    Point(x,y);
}
Node::Node(int id, double x, double y){
    this->_id   = id;
    this->x_    = x;
    this->y_    = y;
}

