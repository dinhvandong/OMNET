/*
 * Node.h
 *
 *  Created on: Jun 27, 2017
 *      Author: admin
 */

#ifndef NODE_H_
#define NODE_H_
#include<GeoMathHelper.h>

class Node:public Point{

public:

    int _id;
    bool check = false;

    Node();
    Node(double x, double y);
    Node(int id, double x, double y);
    int id() const{

        return _id;
    }
    int X() const{

           return x_;
       }

    int Y() const{

           return y_;
       }
};

#endif /* NODE_H_ */
